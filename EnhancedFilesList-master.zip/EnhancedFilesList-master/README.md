# EnhancedFilesList
Ever wanted to customize the Files related list? Now you can! Use the Enhanced Files List component on record, app, or home pages. Select up to 10 fields to display, including custom Content Version fields. Control list behavior without writing any code.

<a href="https://githubsfdeploy.herokuapp.com?owner=SalesforceLabs&repo=EnhancedFilesList">
  <img alt="Deploy to Salesforce"
       src="https://raw.githubusercontent.com/afawcett/githubsfdeploy/master/deploy.png">
</a>
